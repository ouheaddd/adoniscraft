WDA - Disable Four Structures
Minecraft 1.21 / 1.21.1; checked against DungeonsArise-1.21.1-2.1.68-release.jar.

Disabled natural generation:
- Bathhouse (dungeons_arise:bathhouse)
- Small Blimp (dungeons_arise:small_blimp)
- Monastery (dungeons_arise:monastery)
- Abandoned Temple (dungeons_arise:abandoned_temple)

Only these four biome tags are replaced with empty lists.
Heavenly Challenger, Heavenly Rider, Heavenly Conqueror and all other WDA structures are unchanged.
Existing generated structures are not deleted.

Installation:
Put this ZIP (do not unpack) in config/paxi/datapacks/ if using Paxi.
Alternatively, put it in saves/<world>/datapacks/ (or <server world>/datapacks/).
Restart the game/server. Check /datapack list enabled.
For multiplayer, install the datapack on the server.
If another datapack replaces these biome tags, load this patch after it.
Removing this datapack restores normal generation in new chunks.
